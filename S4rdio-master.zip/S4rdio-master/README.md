<div align=center>
<p align="center"><img src="https://www.linkpicture.com/q/Nami-designstyle-friday-m_1.png" width="400px" height="100px" alt="ddos"></p>
 <p>
 <img src="https://img.shields.io/github/stars/cutipu/HTTP-Flood?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/cutipu/HTTP-Flood?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/cutipu/HTTP-Flood?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>
 HTTP-Flood with URLLIB<br/><br/>
<p align="center"><img src="https://www.linkpicture.com/q/nami-lol-png-6.png" height="200px" alt="ddos"></p>
</div>

```sh
- proxy support
- useragent random
- referer random
 
```
<div align=center>
 <img src="https://img.shields.io/badge/Python-FFDD00?style=for-the-badge&logo=python&logoColor=blue"/></br>
</div>

## ATTACK
![hasoki](https://www.linkpicture.com/q/nami-2.png)


## Grouptelegram
https://t.me/adfhjktewwyjqk

## Usage
```sh
python ddos.py or python3 ddos.py
```

## Contact Developer
```sh
 Buy Me a Coffee BTC: 34zoKEUcZ42mKEUc1gB836k9puQ1MiugNr
```

